/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   xtensor_lib.h
 * Author: ltsach
 *
 * Created on September 2, 2024, 10:39 AM
 */

#ifndef XTENSOR_LIB_H
#define XTENSOR_LIB_H
#include <string>
#include <sstream>
using namespace std;

#include "xtensor/xio.hpp"
#include "xtensor/xview.hpp"
#include "xtensor/xslice.hpp"
#include "xtensor/xbuilder.hpp"
#include "xtensor-blas/xlinalg.hpp"
#include "xtensor/xrandom.hpp"
#include "xtensor/xindex_view.hpp"
#include "xtensor/xsort.hpp"
#include "xtensor/xarray.hpp"
#include <ctime>

typedef std::size_t ulong;
typedef xt::xarray<ulong> ulong_array;
typedef xt::xarray<double> double_array;
enum class_metrics{
    ACCURACY = 0,
    PRECISION_MACRO,
    PRECISION_WEIGHTED,
    RECALL_MACRO,
    RECALL_WEIGHTED,
    F1_MEASURE_MACRO,
    F1_MEASURE_WEIGHTED,
    NUM_CLASS_METRICS
};


string shape2str(xt::svector<std::size_t> vec); //chuyển đổi một vector kích thước (shape) thành một chuỗi (string).

int positive_index(int idx, int size);
//đảm bảo rằng chỉ số idx luôn nằm trong phạm vi dương của một mảng kích thước size.

xt::xarray<double> outer_stack(xt::xarray<double> X, xt::xarray<double>  Y);
//Hàm này tính tích ngoài (outer product) của hai mảng X và Y và sau đó ghép chúng lại với nhau (stack).

xt::xarray<double> diag_stack(xt::xarray<double> X);
//xt::array: mảng đa chiều.
//Hàm này có thể ghép mảng X trên đường chéo (diagonal) của một mảng lớn hơn

xt::xarray<double> matmul_on_stack(xt::xarray<double> X, xt::xarray<double>  Y);
/* Hàm này thực hiện phép nhân ma trận (matrix multiplication) giữa hai mảng X và Y và có thể xếp 
chồng (stack) các kết quả. */

xt::xarray<ulong> confusion_matrix(xt::xarray<ulong> y_true, xt::xarray<ulong> y_pred);
//Hàm này tính ma trận nhầm lẫn (confusion matrix) từ nhãn đúng (y_true) và nhãn dự đoán (y_pred).
/* ví dụ: Confusion Matrix: Ma trận nhầm lẫn là một công cụ đánh giá phổ biến trong các bài toán phân loại. 
Nó cho thấy số lần mà mỗi nhãn thực sự được dự đoán chính xác hoặc bị dự đoán nhầm thành các nhãn khác. */

xt::xarray<ulong> class_count(xt::xarray<ulong> confusion);
//Chức năng: Hàm này tính toán số lượng mẫu cho mỗi lớp từ ma trận nhầm lẫn (confusion matrix).
double_array calc_metrics(ulong_array y_true, ulong_array y_pred);
/* Hàm này tính toán các chỉ số đánh giá (metrics) như độ chính xác (accuracy), 
độ nhạy (recall), độ chính xác (precision), và F1 score dựa trên nhãn thực tế (y_true) và nhãn dự đoán (y_pred).
*/



#endif /* XTENSOR_LIB_H */

